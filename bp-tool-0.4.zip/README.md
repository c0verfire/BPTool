# bp-tool-0.4 (Belfast)

The Palo Alto Best Practices Tool is a script that is used to assess Best Practice Configurations on Palo Alto Firewalls.

New to 04!! <br>
Rule BP01016 - Ensure that Firewall Dynamic Updates are Processing <br>
Rule BP01017 - Ensure that Dynamic Update Times are Configured Properly <br>

Added Customer Name - Add's Customer Name to Report. <br>
Added Sleep Timer - Allows the Engineer to specify a Sleep Time between each query. Default is zero seconds. <br>
Added Description as to what rule is running <br>
Added End of File Banner <br>
Shut Off URLLib Warnings <br>
